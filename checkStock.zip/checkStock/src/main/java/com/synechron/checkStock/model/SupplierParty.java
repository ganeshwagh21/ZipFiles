package com.synechron.checkStock.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SupplierParty {
	
	private String LocationName;

	public SupplierParty() {
		super();
	}

	public SupplierParty(String locationName) {
		super();
		LocationName = locationName;
	}

	@JacksonXmlProperty(localName="LocationName")
	public String getLocationName() {
		return LocationName;
	}

	public void setLocationName(String locationName) {
		LocationName = locationName;
	}

	@Override
	public String toString() {
		return "SupplierParty [LocationName=" + LocationName + "]";
	}
	
	

}
