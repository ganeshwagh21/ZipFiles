package com.synechron.checkStock.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JacksonXmlRootElement(localName ="StockReport")
@JsonIgnoreProperties(ignoreUnknown = true)
public class StockReport {

	@JacksonXmlProperty(localName = "ItemDetail")
	private ItemDetail itemDetail;
	
	

	public StockReport() {
		super();
	}

	public StockReport(ItemDetail itemDetail) {
		super();
		this.itemDetail = itemDetail;
	}

	public ItemDetail getItemDetails() {
		return itemDetail;
	}

	public void setItemDetails(ItemDetail itemDetail) {
		this.itemDetail = itemDetail;
	}

	@Override
	public String toString() {
		return "StockReport [itemDetail=" + itemDetail + "]";
	}
	
	
}
