package com.synechron.checkStock.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemDetail {

	@JacksonXmlProperty(localName = "Stock")
    @JacksonXmlElementWrapper(useWrapping = false)
	private Stock[] stock;
	

	public Stock[] getStocks() {
		return stock;
	}

	public void setStocks(Stock[] stocks) {
		this.stock = stocks;
	}

	
	
}
