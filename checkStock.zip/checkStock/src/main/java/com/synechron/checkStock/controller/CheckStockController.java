package com.synechron.checkStock.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.synechron.checkStock.model.Stock;
import com.synechron.checkStock.model.StockReport;

@Controller
public class CheckStockController {
	
	@RequestMapping(value = "/getStockDetails", method= RequestMethod.GET)
    public ModelAndView getStockDetails ( @RequestParam("isbn") String isbn )    
    
    {   
    	ModelAndView modelAndView = new ModelAndView("stockDetails");
    	System.out.println("In getStockDetails Web service  "+isbn);
    	String body = "<StockEnquiry version=\"1.0\"><Header><StockEnquiryNumber>001</StockEnquiryNumber><IssueDateTime>20061018</IssueDateTime><PurposeCode>Original</PurposeCode><BuyerParty><PartyID><PartyIDType>SAN</PartyIDType><Identifier>ipage12</Identifier></PartyID></BuyerParty><SourceParty><PartyID><PartyIDType>SAN</PartyIDType><Identifier>7654321</Identifier></PartyID></SourceParty><SupplierParty><PartyID><PartyIDType>SAN</PartyIDType><Identifier>1697978</Identifier></PartyID></SupplierParty><StockQuantityType>OnHand</StockQuantityType><StockQuantityType>OnOrder</StockQuantityType><StockQuantityType>CBO</StockQuantityType></Header><RequestDetail><LineNumber>1</LineNumber><ProductID><ProductIDType>ISBN</ProductIDType><Identifier>"+isbn+"</Identifier></ProductID></RequestDetail><Summary><NumberOfLines>1</NumberOfLines></Summary></StockEnquiry>";	
    	RestTemplate restTemplate = new RestTemplate();
    	HttpHeaders headers = new HttpHeaders();
    	headers.setContentType(MediaType.APPLICATION_XML);
    	
    	HttpEntity<String> request = new HttpEntity<String>(body, headers);
    	ResponseEntity<String> response = restTemplate.postForEntity("http://tb2bigus.ingrambook.com/ReSTStockCheck/API/RestStockService.svc/restsc", request, String.class);    	
    	
        
        String xmlString = response.getBody();
        XmlMapper xmlMapper = new XmlMapper();
        
		try {
			StockReport stockReport = xmlMapper.readValue(xmlString, StockReport.class);
			// List<Stock> myObjects = Arrays.asList(xmlMapper.readValue(xmlString, Stock[].class));			
			
			//List<Stock> StockList = Arrays.asList(stockReport.getItemDetails().getStocks());
			Stock[] StockList = stockReport.getItemDetails().getStocks();
			if (null == StockList) {
				return new ModelAndView("index", "isbn", isbn);
			}
			
			for(Stock stock: stockReport.getItemDetails().getStocks())
				System.out.println(stock.toString());
			List<Stock> altStockList=new ArrayList<Stock>();
			List<Stock> primaryStockList = new ArrayList<Stock>();
			
			for (Stock stock : StockList) {
					//String shortLocation = "";
					String dcLocation = stock.getSupplierParty().getLocationName();
					
					if (dcLocation.contains("La Vergne, TN")) {					
						stock.getSupplierParty().setLocationName( "TN" );
						primaryStockList.add(stock);					
					} else if(dcLocation.contains("Ft Wayne, IN" ) ) {
						stock.getSupplierParty().setLocationName( "IN" );
						primaryStockList.add(stock);
					} else if(dcLocation.contains("Chambersburg, PA")) {
						stock.getSupplierParty().setLocationName( "PA-C" );
						altStockList.add(stock);
					} else if(dcLocation.contains( "Allentown, PA" )) {
						stock.getSupplierParty().setLocationName( "PA-A" );
						altStockList.add(stock);
					} else if(dcLocation.contains( "Roseburg, OR" )) {
						stock.getSupplierParty().setLocationName( "OR" );
						altStockList.add(stock);
					} else if(dcLocation.contains( "Fresno, CA" )) {
						stock.getSupplierParty().setLocationName( "CA" );
						altStockList.add(stock);
					} else if(dcLocation.contains( "Fairfield, OH" )) {
						stock.getSupplierParty().setLocationName( "OH" );
						altStockList.add(stock);
					}			
			}				
			
		    modelAndView.addObject("altStockList",altStockList);
		    modelAndView.addObject("primaryStockList",primaryStockList);		       
		    return modelAndView;	
		
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}			
        
		 return modelAndView;
    }

}
