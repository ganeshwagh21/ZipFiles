package com.synechron.checkStock.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Stock implements Serializable {
	

	private static final long serialVersionUID = -7596043903777061405L;
	private String onHand;
	private String onOrder;
	private SupplierParty supplierParty;	
	public Stock() {
		super();
	}


	public Stock(String locationName, String onHand, String onOrder, SupplierParty supplierParty) {
		super();
		this.supplierParty = supplierParty;
		this.onHand = onHand;
		this.onOrder = onOrder;
	}
	

	@JacksonXmlProperty(localName="SupplierParty")
	public SupplierParty getSupplierParty() {
		return supplierParty;
	}


	public void setSupplierParty(SupplierParty supplierParty) {
		this.supplierParty = supplierParty;
	}
	

	@JacksonXmlProperty(localName="OnHand")
	public String getOnHand() {
		return onHand;
	}	


	public void setOnHand(String onHand) {
		this.onHand = onHand;
	}

	 @JacksonXmlProperty(localName="OnOrder")
	public String getOnOrder() {
		return onOrder;
	}


	public void setOnOrder(String onOrder) {
		this.onOrder = onOrder;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}	
	
	@Override
	public String toString() {
		return "Stock [onHand=" + onHand + ", onOrder=" + onOrder + ", supplierParty=" + supplierParty.toString() + "]";
	}

}
